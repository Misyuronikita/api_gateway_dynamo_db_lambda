import json
import boto3

client = boto3.resource('dynamodb')

def lambda_handler(event, context):
    table_name = "DynamoDB_test"
    table = client.Table(table_name)
    response = table.scan()
    return {
        'statusCode': 200,
        'body': json.dumps(response['Items'])
    }
